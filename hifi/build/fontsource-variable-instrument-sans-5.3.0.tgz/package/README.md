# Fontsource Instrument Sans

[![npm (scoped)](https://img.shields.io/npm/v/@fontsource-variable/instrument-sans?color=brightgreen)](https://www.npmjs.com/package/@fontsource-variable/instrument-sans) [![Generic badge](https://img.shields.io/badge/fontsource-passing-brightgreen)](https://github.com/fontsource/fontsource) [![Monthly downloads](https://badgen.net/npm/dm/@fontsource-variable/instrument-sans)](https://github.com/fontsource/fontsource) [![Total downloads](https://badgen.net/npm/dt/@fontsource-variable/instrument-sans)](https://github.com/fontsource/fontsource)

The CSS and web font files to easily self-host the “Instrument Sans” variable font. Please visit the main [Fontsource website](https://fontsource.org/fonts/instrument-sans) to view more details on this package.

## Quick Installation

Fontsource offers multiple methods to import the CSS, including using a bundler like Vite or using SASS. You can find full documentation [here](https://fontsource.org/docs/getting-started/introduction).

```javascript
npm install @fontsource-variable/instrument-sans
```

Within your app entry file or site component, import it in.

```javascript
import "@fontsource-variable/instrument-sans"; // Defaults to wght axis
import "@fontsource-variable/instrument-sans/wght.css"; // Specify axis
import "@fontsource-variable/instrument-sans/wght-italic.css"; // Specify axis and style
```

Supported variables:
- Weights: `[400,500,600,700]`
- Styles: `[italic,normal]`
- Subsets: `[latin,latin-ext]`
- Axes: `[wdth,wght]`

> Note: `italic` may not be supported by all fonts. To learn more about what axes and styles are supported, please visit the [Fontsource website](https://fontsource.org/fonts/instrument-sans).

Finally, you can reference the font name in a CSS stylesheet, CSS Module, or CSS-in-JS.

```css
body {
  font-family: "Instrument Sans Variable";
}
```

## Licensing
Always make sure to read the license for each font you use. Most of the fonts in the collection use the SIL Open Font License, v1.1. Some fonts use the Apache 2 license. The Ubuntu fonts use the Ubuntu Font License v1.0.

Copyright 2022 The Instrument Sans Project Authors (https://github.com/Instrument/instrument-sans) InstrumentSans-Italic[wdth,wght].ttf: Copyright 2022 The Instrument Sans Project Authors (https://github.com/Instrument/instrument-sans)
[OFL-1.1](https://openfontlicense.org)

## Other Notes
Font version (provided by source): `v4`.

If you have any suggestions or ideas to improve the performance of font loading or expand the existing library, feel free to star and contribute to this repository. You can share your suggestions or ideas by creating an [issue](https://github.com/fontsource/fontsource/issues).